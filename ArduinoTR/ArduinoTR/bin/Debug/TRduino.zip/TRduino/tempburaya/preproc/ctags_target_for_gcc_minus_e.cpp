# 1 "C:\\Users\\HP\\Desktop\\TRduino\\ArduAhmetTemp\\ArduAhmetTemp.ino"
# 1 "C:\\Users\\HP\\Desktop\\TRduino\\ArduAhmetTemp\\ArduAhmetTemp.ino"
void setup(){
    pinMode(5,0x1);

}
void loop(){
    digitalWrite(5,1);
    delay(100);
    digitalWrite(5,0);
    delay(100);

}
