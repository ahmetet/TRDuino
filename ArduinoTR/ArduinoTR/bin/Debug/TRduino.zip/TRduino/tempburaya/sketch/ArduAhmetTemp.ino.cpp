#include <Arduino.h>
#line 1 "C:\\Users\\HP\\Desktop\\TRduino\\ArduAhmetTemp\\ArduAhmetTemp.ino"
#line 1 "C:\\Users\\HP\\Desktop\\TRduino\\ArduAhmetTemp\\ArduAhmetTemp.ino"
#line 1 "C:\\Users\\HP\\Desktop\\TRduino\\ArduAhmetTemp\\ArduAhmetTemp.ino"
void setup();
#line 5 "C:\\Users\\HP\\Desktop\\TRduino\\ArduAhmetTemp\\ArduAhmetTemp.ino"
void loop();
#line 1 "C:\\Users\\HP\\Desktop\\TRduino\\ArduAhmetTemp\\ArduAhmetTemp.ino"
void setup(){
    pinMode(5,OUTPUT); 

}
void loop(){
    digitalWrite(5,1);
    delay(100);
    digitalWrite(5,0);
    delay(100);

}

